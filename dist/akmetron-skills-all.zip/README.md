# Навыки Акметрон для Claude

Пять навыков (skills) для Claude, собранных в инженерно-технической компании
[Акметрон](https://akmetron.ru) — контрольно-измерительное оборудование и
радиоэлектроника. Работают в Claude.ai, Claude Desktop, Cowork и Claude Code.

Всё на русском языке: и сами инструкции, и то, что навыки выдают на выходе.

| Навык | Что делает | Выход |
|---|---|---|
| [`akmetron-design-system`](skills/akmetron-design-system) | Дизайн-система компании: лендинги, HTML-артефакты, React-компоненты, дашборды, постеры в фирменном стиле | HTML / JSX |
| [`datasheet-ru-localizer`](skills/datasheet-ru-localizer) | Полный перевод технического даташита на русский, с сохранением таблиц и структуры 1:1, и вёрстка фирменного PDF | PDF A4 |
| [`meeting-protocol`](skills/meeting-protocol) | Протокол встречи из расшифровки или заметок: повестка, решения, задачи по владельцам со сроками | PDF A4 |
| [`message-format-tg-bitrix`](skills/message-format-tg-bitrix) | Оформление текста под Telegram и Битрикс24 — чистый plain text без markdown-таблиц | текст |
| [`plain-language-doc`](skills/plain-language-doc) | Документы и отчёты простым языком, со схемами и графиками по сетке | PDF A4 |

---

## Установка

### Claude.ai, Claude Desktop и Cowork — загрузкой zip

Каждый навык лежит в [`dist/`](dist) отдельным архивом, готовым к загрузке.

1. Скачайте нужный zip из [`dist/`](dist) (или возьмите все сразу — `akmetron-skills-all.zip`).
2. В Claude откройте **Settings → Capabilities → Skills**.
3. Нажмите **Upload skill** и выберите zip.
4. Повторите для остальных навыков.

Навык появится в списке и начнёт срабатывать сам, когда вы сформулируете
подходящую задачу. Вызвать вручную — командой со слешем, например
`/meeting-protocol`.

### Claude Code — одной командой

```bash
git clone https://github.com/hidtk/akmetron-skills.git
cd akmetron-skills
./install.sh
```

Скрипт копирует навыки в `~/.claude/skills/`. Поставить в проект, а не глобально:

```bash
./install.sh --project /путь/к/проекту
```

Поставить только часть:

```bash
./install.sh meeting-protocol datasheet-ru-localizer
```

### Вручную

```bash
cp -r skills/meeting-protocol ~/.claude/skills/
```

---

## Как это работает

Навык — это папка с файлом `SKILL.md` и, при необходимости, вложенными
ресурсами. В заголовке `SKILL.md` описано, когда навык должен срабатывать;
Claude читает описание и подключает навык сам, без явной команды.

```
meeting-protocol/
├── SKILL.md              инструкция и триггеры
└── assets/
    ├── protokol.css      фирменная вёрстка
    ├── renderer.js       сборка HTML
    ├── render_pdf.py     печать в PDF
    └── fonts/            Montserrat + Inter, подмножества
```

Три навыка из пяти печатают PDF и несут с собой шрифты, чтобы результат
выглядел одинаково на любой машине. Поэтому архивы весят сотни килобайт,
а не единицы.

### Что нужно для PDF-навыков

`datasheet-ru-localizer`, `meeting-protocol` и `plain-language-doc` печатают
через headless-браузер. В окружении Claude всё уже есть; локально понадобится
Python 3 и Playwright с Chromium:

```bash
pip install playwright && playwright install chromium
```

---

## Свой бренд вместо Акметрона

Навыки не зашиты намертво под одну компанию — фирменный стиль вынесен в
отдельные файлы.

- **Цвета, шрифты, радиусы, тени** — в `skills/akmetron-design-system/assets/akmetron.css`,
  блок `:root`. Поменяйте значения переменных, остальное подтянется.
- **Логотип** — `assets/logo-mark.png`, **фоновый мотив** — `assets/puzzle-pattern.svg`.
- **Тон текста и формулировки** — `references/voice.md`.
- **Вёрстка PDF** — `protokol.css` и `datasheet.css` в соответствующих навыках.
- **Термины перевода** — `skills/datasheet-ru-localizer/references/glossary.md`.

Форк и правка этих файлов дают вам тот же набор под свой бренд.

---

## Лицензии

Код и тексты навыков — MIT, см. [LICENSE](LICENSE).

Шрифты в `assets/fonts/` — Montserrat и Inter, распространяются по
SIL Open Font License 1.1, см. [NOTICE.md](NOTICE.md).

---

## Вклад

Замечания и правки — через issues и pull requests. Если собрали свой вариант
под другую компанию, ссылка на форк в issue будет полезна остальным.
